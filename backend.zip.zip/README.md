# Backend (Express)
- Copy .env.example to .env and set MONGODB_URI and JWT_SECRET
- `npm install`
- `npm run dev` (requires nodemon) or `npm start`
