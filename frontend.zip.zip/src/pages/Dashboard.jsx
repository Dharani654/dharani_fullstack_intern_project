import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Dashboard(){
  const [tasks, setTasks] = useState([]);
  const [q, setQ] = useState('');
  const token = localStorage.getItem('token');

  useEffect(()=>{ fetchTasks(); }, []);

  async function fetchTasks(){
    try{
      const res = await axios.get((import.meta.env.VITE_API_BASE || 'http://localhost:5000') + '/api/tasks' + (q ? '?q='+encodeURIComponent(q) : ''), { headers: { Authorization: 'Bearer ' + token } });
      setTasks(res.data);
    }catch(err){ console.error(err); alert('Could not fetch tasks.'); }
  }

  async function createTask(){
    const title = prompt('Task title');
    if(!title) return;
    await axios.post((import.meta.env.VITE_API_BASE || 'http://localhost:5000') + '/api/tasks', { title }, { headers: { Authorization: 'Bearer ' + token } });
    fetchTasks();
  }

  async function toggle(id, completed){
    await axios.put((import.meta.env.VITE_API_BASE || 'http://localhost:5000') + '/api/tasks/' + id, { completed: !completed }, { headers: { Authorization: 'Bearer ' + token } });
    fetchTasks();
  }

  async function del(id){ if(!confirm('Delete?')) return; await axios.delete((import.meta.env.VITE_API_BASE || 'http://localhost:5000') + '/api/tasks/' + id, { headers: { Authorization: 'Bearer ' + token } }); fetchTasks(); }

  function logout(){ localStorage.removeItem('token'); window.location.href = '/login'; }

  return (
    <div className="p-6 bg-white border rounded">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl">Dashboard</h1>
        <div className="flex gap-2">
          <input placeholder="Search" value={q} onChange={e=>setQ(e.target.value)} className="border p-2 rounded"/>
          <button onClick={fetchTasks} className="px-3 py-2 border rounded">Search</button>
          <button onClick={createTask} className="px-3 py-2 bg-blue-600 text-white rounded">New Task</button>
          <button onClick={logout} className="px-3 py-2 border rounded">Logout</button>
        </div>
      </div>

      <ul>
        {tasks.map(t => (
          <li key={t._id} className="p-3 border mb-2 rounded flex justify-between items-center">
            <div>
              <div className="font-semibold">{t.title}</div>
              <div className="text-sm text-gray-600">{t.description}</div>
            </div>
            <div className="flex gap-2">
              <button onClick={()=>toggle(t._id, t.completed)} className="px-2 py-1 border rounded">{t.completed ? 'Undo' : 'Done'}</button>
              <button onClick={()=>del(t._1d)} className="px-2 py-1 border rounded">Delete</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
