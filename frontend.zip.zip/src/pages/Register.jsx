import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Register(){
  const [form, setForm] = useState({ name:'', email:'', password:'' });
  const [err, setErr] = useState('');
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    try{
      await axios.post((import.meta.env.VITE_API_BASE || 'http://localhost:5000') + '/api/auth/signup', form);
      alert('Registered — please login');
      navigate('/login');
    }catch(e){
      setErr(e?.response?.data?.msg || 'Error');
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 border rounded bg-white">
      <h2 className="text-xl mb-4">Register</h2>
      {err && <div className="text-red-600 mb-2">{err}</div>}
      <form onSubmit={submit} className="flex flex-col">
        <input required className="p-2 border mb-2 rounded" placeholder="Name" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} />
        <input required className="p-2 border mb-2 rounded" placeholder="Email" type="email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})} />
        <input required className="p-2 border mb-4 rounded" placeholder="Password" type="password" value={form.password} onChange={e=>setForm({...form, password:e.target.value})} />
        <button className="px-4 py-2 bg-blue-600 text-white rounded">Sign up</button>
      </form>
    </div>
  );
}
