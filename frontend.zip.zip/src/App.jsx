import { Routes, Route, Link, Navigate } from 'react-router-dom';
import Register from './pages/Register';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';

function App(){
  const token = localStorage.getItem('token');

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="p-4 bg-white shadow">
        <div className="max-w-4xl mx-auto flex justify-between">
          <h1 className="font-bold">Intern Task</h1>
          <nav className="flex gap-2">
            <Link to="/" className="text-sm">Home</Link>
            {!token ? <Link to="/login" className="text-sm">Login</Link> : <Link to="/dashboard" className="text-sm">Dashboard</Link>}
          </nav>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-6">
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/register" element={<Register/>} />
          <Route path="/login" element={<Login/>} />
          <Route path="/dashboard" element={token ? <Dashboard/> : <Navigate to="/login" />} />
        </Routes>
      </main>
    </div>
  );
}

function Home(){
  return (
    <div className="p-6 border rounded bg-white">
      <h2 className="text-xl font-semibold mb-2">React + Express Starter</h2>
      <p className="mb-4">Register, login and manage tasks. Built for the Frontend Developer Intern assignment.</p>
      <div className="flex gap-2">
        <Link to="/register" className="px-4 py-2 bg-blue-600 text-white rounded">Register</Link>
        <Link to="/login" className="px-4 py-2 border rounded">Login</Link>
      </div>
    </div>
  );
}

export default App;
