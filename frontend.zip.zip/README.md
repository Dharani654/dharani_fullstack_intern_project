# Frontend (React + Vite)
- Start: `npm install` then `npm run dev`
- The app expects VITE_API_BASE environment variable to point to backend, default is http://localhost:5000
- Example: create a .env.local with `VITE_API_BASE=http://localhost:5000`
